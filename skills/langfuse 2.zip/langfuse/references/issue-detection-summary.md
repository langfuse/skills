# Detecting Issues in Production LLM Traffic — What & Why

A shareable summary of how we triage a Langfuse project's recent traffic for problems. The goal isn't to catch crashes — those get noticed. It's to surface the **silent** problems: things that don't throw errors but still degrade the product (bad retrieval, dead evaluators, creeping latency, quietly-useless answers).

---

## The mindset (why we do it this way)

| Principle | Why it matters |
|---|---|
| **Comprehensive over fast** | A quick glance catches loud failures and misses the silent majority. We walk a full checklist so nothing is skipped. |
| **Evidence, not vibes** | Every finding carries numbers (counts, %) and example trace IDs, so it can be verified and acted on — not argued about. |
| **Silent issues first** | Crashes get reported by users. Degraded retrieval, dead evaluators, and slow latency drift do not — so no one else will catch them. |
| **Segment before concluding** | A healthy-looking aggregate can hide one broken user, version, tool, or release. Slice before declaring anything clean. |
| **Status flags ≠ quality** | A tool returning `ok:true` with 3 results can still be returning irrelevant garbage. We inspect content, not just success codes. |
| **A clean dimension is a finding** | Recording "checked, no issue" tells the reader it was verified, not skipped. |

---

## Step 0 — Separate the product from the machinery

The single easiest way to get triage wrong. A Langfuse project mixes real app traffic with **evaluator executions** (LLM-as-a-judge runs), dataset/experiment runs, and playground activity. **Why it matters:** if you don't exclude the machinery, your error rates, latency, and cost are all polluted and every conclusion is suspect. Summarize by `environment` and `name` first, pick the product traffic, and report what was included/excluded.

---

## What to check, and why

The first group is what naive triage already covers. The later groups are where issues **silently hide** — they are the reason this exists.

### A. Reliability & errors *(the obvious ones)*
Hard errors, failed tool calls, empty/null outputs, truncated answers, timeouts/retries.
**Why:** baseline correctness. Loud, but still must be quantified by type and rate.

### B. Latency
End-to-end percentiles (median/p90/p99), which step dominates, and outliers correlated with a tool/model/user.
**Why:** a fine median can hide an unacceptable tail; users feel p99, not the average.

### C. Cost & tokens
Total and per-trace cost, token distributions, runaway prompts, and **waste** (tokens spent on content that adds no value).
**Why:** silent cost explosions and growing-context sessions bleed money without any error.

### D. Tool / agent behavior
Tool failure rates and loops, malformed tool arguments, **retrieval/RAG relevance**, and tool coverage gaps.
**Why:** retrieval is the classic silent killer — a search tool can be "100% successful" and return useless results. Content quality, not success codes, is the signal.

### E. Scores & evaluators
**Enumerate every score first, then define what "bad" means for each** — split by source (LLM-judge evaluators, **user feedback** like thumbs/ratings, human annotations). Then check distributions, dead/non-discriminating evaluators, missing scores, and regressions.
**Why:** polarity is not always "low/False" — high `toxicity` is bad, a categorical `"incorrect"` is bad. And a thumbs-down or 1-star is **ground-truth dissatisfaction**, not a proxy — it ranks highly. An evaluator stuck at one constant value may be mis-wired and silently monitoring nothing.

### F. User friction & conversation quality
**Read a sample of full conversations end-to-end** — real user inputs and agent outputs, turn by turn — then quantify follow-up/clarification rate, frustration, multi-turn loops, and abandonment.
**Why:** a conversation can have no errors, good latency, and a passing evaluator while the agent quietly misunderstood the user or gave a technically-correct-but-useless reply. Derived signals *quantify* friction; reading transcripts is how you *catch* it in the first place.

### G. Output quality & safety
Refusals/non-answers, format/contract violations (e.g. invalid JSON), faithfulness/hallucination risk, and safety/PII/compliance issues.
**Why:** these damage trust and create real risk, and most are invisible to a status-code check.

### H. Inputs & scope
Out-of-scope requests, malformed/adversarial inputs, and language mismatches (user asks in X, agent answers in Y).
**Why:** how the system handles inputs it wasn't built for reveals both UX gaps and attack surface.

### I. Segmentation & regressions
Re-slice every metric by version/release, user/session, prompt version, model/config, and tool/environment/tag.
**Why:** a deploy or prompt change can regress one slice while the aggregate looks fine. This is where "everything looks healthy" findings get overturned.

### J. Volume & coverage meta
Traffic spikes/drops, monitoring coverage (% of traffic with scores), and an explicit note of **what was NOT covered** (sampling caps, pagination limits, dimensions that couldn't be evaluated).
**Why:** silent truncation of the analysis itself reads as "all clear" when it isn't. Honesty about coverage is part of the result.

---

## Ranking findings

Each finding is scored on three axes, then bucketed:

**Severity** (user/business impact) × **Prevalence** (% of traffic affected) × **Silence** (does it error loudly, or pass unnoticed?). Silent issues rank *higher* — no one else will catch them.

| Bucket | Meaning |
|---|---|
| **P0** | Broken or harmful, often silent, affecting many requests |
| **P1** | Clear quality/friction degradation on a meaningful slice |
| **P2** | Real but lower impact or prevalence |
| **P3** | Worth a look / hygiene / "verify this can even fire" |

---

## What a finished triage looks like

A markdown report containing: the method (window, included/excluded counts), a headline metrics table, findings ordered by priority (each with evidence + example trace IDs + why it matters + suggested fix + root-cause hypothesis), an explicit **"verified non-issues"** section, a suggested order of action, and open questions.
